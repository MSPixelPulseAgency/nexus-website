Editable master (live text). Install the two fonts in this folder first:
  Cinzel (use Bold 700)   - NEXUS EDUCATION
  Gantari (use Bold 700)  - PRIVATE SCHOOL
Both are free under the SIL Open Font License (OFL files included).
The logo files everyone else uses (SVG/PNG/JPEG) already have the lettering converted to outlines and need no fonts.
