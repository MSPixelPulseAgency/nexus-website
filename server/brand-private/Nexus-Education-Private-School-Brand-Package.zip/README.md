# Nexus Education Private School — Brand Kit

Version 1.0 · September 2026 · Master vector source of truth for the Nexus identity.

## Source of truth

The approved logo existed only as raster artwork (website folder `public/brand/`). The master SVG in this kit rebuilds it as
true vector artwork:

- **Crest**: reconstructed from the approved transparent crest and verified against it (99.5% / 98% pixel agreement).
- **NEXUS EDUCATION**: set in **Cinzel Bold** (SIL Open Font License) using the font's real glyph outlines, sized,
  tracked and positioned to the approved layout. The original logo used a commercial display face (most likely
  Adobe Charlemagne Std Bold) that is not available; Cinzel was chosen as the closest open-licence match.
- **PRIVATE SCHOOL**: set in **Gantari Bold** (SIL OFL) real glyph outlines with the approved wide tracking.

The distributed SVGs contain outlined paths only (no fonts needed, no embedded images). An editable live-text master
and both fonts are in `01-Logos/Editable-Master/`.

Colours were sampled from the approved artwork: Crest Blue `#111984`, Crest Gold `#C59728`.

## Folder structure

```
Nexus-Brand-Kit-Claude/
├── 01-Logos/
│   ├── Nexus-Education-Private-School-Logo-Master.svg   ← master file of record (layered ids)
│   ├── Primary/              stacked full-colour · SVG · PNG 600/1200/2400/4000 · JPEG 2400
│   ├── Horizontal/           crest beside wordmark · colour, white, black · SVG · PNG · JPEG
│   ├── White-Reversed/       solid white · SVG · transparent PNG · navy preview PNG/JPEG
│   ├── Dark-Background/      white + gold wreath · SVG · transparent PNG · navy preview PNG/JPEG
│   ├── Editable-Master/     live-text master + Cinzel and Gantari fonts (OFL)
│   ├── Monochrome/           Black and Grayscale · SVG · PNG · JPEG
│   ├── Background-Variants/  On-Navy · On-Blue · On-Cream · On-White (SVG with background, PNG, JPEG)
│   ├── Logo-Mark/            crest only · colour, white, black, on navy · SVG · PNG 256–2048
│   └── Web-Icons/            favicon.svg, favicon.ico, favicon 16–512 PNG, Apple touch icon 180,
│                             icon 192/512, maskable 512, navy app icon 1024
├── 02-Brand-Guidelines/
│   ├── Nexus-Education-Private-School-Brand-Guidelines.pdf   (18 pages, A4 landscape)
│   └── Editable-Source/      HTML sources for the PDF and quick reference (+ Manrope font, OFL)
├── 03-Quick-Reference/       Nexus-Education-Private-School-Brand-Quick-Reference.png (2480 × 3508)
├── 04-Colour-and-Type/       Nexus-Brand-Colours.json / .css tokens, Typography.md
└── 05-Package/               Nexus-Education-Private-School-Brand-Package.zip (everything above)
```

## Which file to use

| Need | File |
| --- | --- |
| Website, apps, anything that scales | `01-Logos/Primary/…Logo-Primary.svg` (or Horizontal / Mark SVG) |
| Documents and slides on white | `…Logo-Primary-1200px.png` (transparent) |
| Navy or dark surfaces | `01-Logos/Dark-Background/…Logo-Dark-Background.svg` / PNG |
| Nexus blue, photography, saturated colour | `01-Logos/White-Reversed/…Logo-White.svg` / PNG |
| Single-colour print, stamps, forms | `01-Logos/Monochrome/…Logo-Black.svg` |
| Favicons and app icons | `01-Logos/Web-Icons/` |
| Print vendors | SVG files plus the guidelines PDF (CMYK approximations on pages 10–11) |

## Rules in one line each

Use only these files; keep proportions; respect clear space (X = cap height, ≈10% of width) and minimum
sizes (primary 120 px / 30 mm, horizontal 160 px / 40 mm, mark 24 px / 8 mm); pick the version with the
strongest contrast; never recolour, retype, rotate, stretch, crop or add effects.

## Regenerating

The kit is generated from the master paths; the editable HTML sources reproduce the PDF and quick reference
in any Chromium browser (print to PDF at 100% scale, no margins).

Brand assets are for authorized use only. Requests: https://nexuseps.com/brand-guidelines
