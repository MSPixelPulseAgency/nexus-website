# Nexus typography

- Brand typeface: **Manrope** (Google Fonts, SIL OFL). Headings ExtraBold 800, emphasis Bold 700, body Medium 500.
- Logo wordmark: **Cinzel Bold** (NEXUS EDUCATION) and **Gantari Bold** with wide tracking (PRIVATE SCHOOL), both SIL OFL. The logo files contain these as outlines; always use the supplied logo files rather than retyping.
