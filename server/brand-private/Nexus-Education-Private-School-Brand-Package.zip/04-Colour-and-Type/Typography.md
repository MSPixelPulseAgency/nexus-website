# Nexus typography

- Brand typeface: **Manrope** (Google Fonts, SIL OFL). Headings ExtraBold 800, emphasis Bold 700, body Medium 500.
- Download: https://fonts.google.com/specimen/Manrope
- Logo letterforms are locked artwork. NEXUS EDUCATION uses custom capitals reconstructed from the approved logo; PRIVATE SCHOOL uses Montserrat Bold with +25% tracking. Never retype the wordmark.
